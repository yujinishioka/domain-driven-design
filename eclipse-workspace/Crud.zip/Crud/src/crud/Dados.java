package crud;

public class Dados {
	
	public static final String USER = "rm92895";
	public static final String PWD = "123";
	
}
