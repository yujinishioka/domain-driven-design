package br.com.scores.model.dao;

import br.com.scores.interfaces.GerenciadorScores;

public class GerenciadorScoresArquivo implements GerenciadorScores {

}
