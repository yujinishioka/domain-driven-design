package br.com.scores.view;

public class FrontScores {

}
